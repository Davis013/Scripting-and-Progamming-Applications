#pragma once
#ifndef Degree_h
#define Degree_h

using namespace std;

enum degree { SECURITY, NETWORK, SOFTWARE };

#endif