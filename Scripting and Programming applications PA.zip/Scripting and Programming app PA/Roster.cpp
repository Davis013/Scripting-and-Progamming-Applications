#include <iostream>
#include <string>
#include "Degree.h"
#include "Student.h"
#include "Roster.h"
#include <array>
#include <string>
using namespace std;

//Roster Class function

//Class Constructor
Roster::Roster(int classSize) {
	this->classSize = classSize;
	this->index = 0;
	for (int i = 0; i < classSize; i++) {
		this->classRosterArray[i] = new Student;
	}
	return;
}
//Get student ID from Student class
string Roster::GetStudentID(int index) {

	string id = classRosterArray[index]->GetID();
	return id;
}
//Creating new Student objects in the classRosterArray
void Roster::add(string studentData) {

	string ID, firstName, lastName, emailAddress;
	int yearsOld, completeTime1, completeTime2, completeTime3;

	if (index < classSize) {

		classRosterArray[index] = new Student();

		int i = studentData.find(",");
		ID = studentData.substr(0, i);
		classRosterArray[index]->SetID(ID);

		int j = i + 1;
		i = studentData.find(",", j);
		firstName = studentData.substr(j, i - j);
		classRosterArray[index]->SetFirstName(firstName);

		j = i + 1;
		i = studentData.find(",", j);
		lastName = studentData.substr(j, i - j);
		classRosterArray[index]->SetLastName(lastName);

		j = i + 1;
		i = studentData.find(",", j);
		emailAddress = studentData.substr(j, i - j);
		classRosterArray[index]->SetEmailAddress(emailAddress);

		j = i + 1;
		i = studentData.find(",", j);
		yearsOld = stoi(studentData.substr(j, i - j));
		classRosterArray[index]->SetAge(yearsOld);

		j = i + 1;
		i = studentData.find(",", j);
		completeTime1 = stoi(studentData.substr(j, i - j));

		j = i + 1;
		i = studentData.find(",", j);
		completeTime2 = stoi(studentData.substr(j, i - j));

		j = i + 1;
		i = studentData.find(",", j);
		completeTime3 = stoi(studentData.substr(j, i - j));
		classRosterArray[index]->SetDaysToComplete(completeTime1, completeTime2, completeTime3);

		j = i + 1;
		i = studentData.find(",", j);
		string type = studentData.substr(j, i - j);
		if (type == "SECURITY") {
			classRosterArray[index]->SetDegreeProgram(SECURITY);
		}
		else if (type == "NETWORK") {
			classRosterArray[index]->SetDegreeProgram(NETWORK);
		}
		else if (type == "SOFTWARE") {
			classRosterArray[index]->SetDegreeProgram(SOFTWARE);
		}
		else {
			cout << "Invalid Degree Choice." << endl;
		}
		index++;
	}
	return;
}
//Remove student from the roster
void Roster::remove(string ID) {

	bool foundStudent = false;
	for (int i = 0; i < classSize; i++) {
		if (classRosterArray[i] == nullptr) {
			continue;
		}
		else if (ID == classRosterArray[i]->GetID()) {
			classRosterArray[i] = nullptr;
			foundStudent = true;
			break;
		}
	}
	if (foundStudent == false) {
		cout << "Error: Student " << ID << " Not Found." << endl;
	}
	else if (foundStudent == true) {
		cout << "Student " << ID << " removed." << endl;
	}
	return;
}
//Print all current students in the roster
void Roster::printAll() {
	cout << "All current students: " << endl;
	for (int i = 0; i < classSize; i++) {
		if (classRosterArray[i] == nullptr)
		{
			continue;
		}
		else {
			classRosterArray[i]->PrintAllStudentInfo();
		}
	}
	cout << endl;
	return;
}
//Print average number of days for a students 3 courses
void Roster::printAverageDaysInCourse(string ID) {
	for (int i = 0; i < classSize; i++) {
		if (ID == classRosterArray[i]->GetID()) {
			int temparray[3] = { classRosterArray[i]->GetDaysToComplete1(), classRosterArray[i]->GetDaysToComplete2(), classRosterArray[i]->GetDaysToComplete3() };
			double averageDays = (static_cast<double>(temparray[0]) + static_cast<double>(temparray[1]) + static_cast<double>(temparray[2])) / 3.0;
			cout << ID << "'s Average Days In Their Courses: " << averageDays << endl;;
		}
	}
	return;
}
//Prints invalid emails
void Roster::printInvalidEmails() {
	for (int i = 0; i < classSize; i++) {
		string emailAddress = classRosterArray[i]->GetEmailAddress();
		if ((emailAddress.find(' ') != string::npos) || (emailAddress.find('.') == string::npos) || (emailAddress.find('@') == string::npos)) {
			cout << classRosterArray[i]->GetID() << "'s email address " << emailAddress << " is invalid." << endl;
		}
	}
	cout << endl;
	return;
}
//Prints all students with a specified degree program
void Roster::printByDegreeProgram(degree degreeProgram) {
	string degreeString;
	if (degreeProgram == SECURITY) {
		degreeString = "SECURITY";
	}
	else if (degreeProgram == NETWORK) {
		degreeString = "NETWORK";
	}
	else if (degreeProgram == SOFTWARE) {
		degreeString = "SOFTWARE";
	}
	else {
		degreeString = "INVALID";
	}
	cout << "Students with degree program: " << degreeString << endl;
	int numberStudents = 0;
	for (int i = 0; i < classSize; i++) {
		if (classRosterArray[i]->GetDegreeProgram() == degreeProgram) {
			classRosterArray[i]->PrintAllStudentInfo();
			numberStudents++;
		}
	}
	if (numberStudents == 0) {
		cout << "No students with this degree found." << endl;
	}

	return;
}
Roster::~Roster() {

	return;
}