// Scripting and Programming app PA.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include "Degree.h"
#include "Student.h"
#include "Roster.h"
#include <string>
#include <array>
using namespace std;

int main()
{
    cout << "Course Title: C867 - Scripting and Programming Applications" << endl;
    cout << "Programming Language Used: C++" << endl;
    cout << "Name: Brandon Davis" << endl;
    cout << "Student ID: 010008848 " << endl << endl;

    //Student Data
    const string studentData[] = {
        "A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
        "A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
        "A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
        "A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
        "A5,Brandon,Davis,Brandondavis013@gmail.com,25,20,16,15,SOFTWARE"
    };

    //Creating Class Roster
    Roster* ClassRoster = new Roster(5);

    //Adding each index of student data to a new Student class object
    for (int i = 0; i < 5; i++) {
        ClassRoster->add(studentData[i]);
    };

    //Printing class roster
    ClassRoster->printAll();

    //Printing invalid emails
    ClassRoster->printInvalidEmails();

    for (int i = 0; i < 5; i++) {

        ClassRoster->printAverageDaysInCourse(ClassRoster->GetStudentID(i));
    }
    cout << endl;

    //Printing students with SOFTWARE Degree
    ClassRoster->printByDegreeProgram(SOFTWARE);
    cout << endl;

    //Removing Student A3
    ClassRoster->remove("A3");
    cout << endl;

    //Printing new class roster
    ClassRoster->printAll();
    cout << endl;

    //Testing "student not found" error
    ClassRoster->remove("A3");
    cout << endl;

    //Destructor
    ClassRoster->~Roster();
    delete ClassRoster;

    system("pause>0");
}