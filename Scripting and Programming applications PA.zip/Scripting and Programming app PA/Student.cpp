#include <iostream>
#include <string>
#include "Degree.h"
#include "Student.h"

using namespace std;

//Student Class Function

//Constructor

Student::Student() {
	this->studentID = "";
	this->firstName = "";
	this->lastName = "";
	this->emailAddress = "";
	this->age = 0;
	this->daysToComplete[0] = 0;
	this->daysToComplete[1] = 0;
	this->daysToComplete[2] = 0;
	this->degreeProgram;
}


//Setting student ID
void Student::SetID(string ID) {
	this->studentID = ID;

	return;
}

//Setting student's first name
void Student::SetFirstName(string firstName) {
	this->firstName = firstName;

	return;
}


//Setting student's last name
void Student::SetLastName(string lastName) {
	this->lastName = lastName;

	return;
}


//Setting student's email address
void Student::SetEmailAddress(string emailAddress) {
	this->emailAddress = emailAddress;

	return;
}


//Setting student's age
void Student::SetAge(int yearsOld) {
	this->age = yearsOld;

	return;
}


//Setting number of days to complete a student's courses
void Student::SetDaysToComplete(int completeTime1, int completeTime2, int completeTime3) {
	this->daysToComplete[0] = completeTime1;
	this->daysToComplete[1] = completeTime2;
	this->daysToComplete[2] = completeTime3;

	return;
}


//Setting student's degree program
void Student::SetDegreeProgram(degree degreeProgram) {
	this->degreeProgram = degreeProgram;

	return;
}

//Getting student id
string Student::GetID() {
	return studentID;
}
//Getting student first name
string Student::GetFirstName() {
	return firstName;
}
//Getting student last name
string Student::GetLastName() {
	return lastName;
}
//Getting student's email address
string Student::GetEmailAddress() {
	return emailAddress;
}
//Getting student's age
int Student::GetAge() {
	return age;
}
//Getting the days to complete
int Student::GetDaysToComplete1() {
	return daysToComplete[0];
}
int Student::GetDaysToComplete2() {
	return daysToComplete[1];
}
int Student::GetDaysToComplete3() {
	return daysToComplete[2];
}
//Getting student's degree program
degree Student::GetDegreeProgram() {
	return degreeProgram;
}
//Prints student ID
void Student::PrintID() {
	cout << studentID;

	return;
}
//Prints student first name
void Student::PrintFirstName() {
	cout << firstName << endl;

	return;
}

//Prints student last name
void Student::PrintLastName() {
	cout << lastName << endl;

	return;
}

//Prints student's email address
void Student::PrintEmailAddress() {
	cout << emailAddress << endl;

	return;
}

//Prints student's age
void Student::PrintAge() {
	cout << age << endl;

	return;
}

//Prints student's days to complete course
void Student::PrintDaysToComplete() {
	cout << daysToComplete[0] << "," << daysToComplete[1] << "," << daysToComplete[2] << endl;

	return;
}

//Prints student's degree program
void Student::PrintDegreeProgram() {
	string degreeString;
	if (degreeProgram == SECURITY) {
		degreeString = "SECURITY";
	}
	else if (degreeProgram == NETWORK) {
		degreeString = "NETWORK";
	}
	else if (degreeProgram == SOFTWARE) {
		degreeString = "SOFTWARE";
	}
	else {
		degreeString = "INVALID";
	}
	cout << degreeString << endl;

	return;
}

//Prints all student's information
void Student::PrintAllStudentInfo() {
	string degreeString;
	if (degreeProgram == SECURITY) {
		degreeString = "SECURITY";
	}
	else if (degreeProgram == NETWORK) {
		degreeString = "NETWORK";
	}
	else if (degreeProgram == SOFTWARE) {
		degreeString = "SOFTWARE";
	}
	else {
		degreeString = "INVALID";
	}
	cout << studentID << " First Name: " << firstName << " Last Name: " << lastName << " Age: " << age << " Days in Course: {" << daysToComplete[0] << "," << daysToComplete[1] << "," << daysToComplete[2] << "} " << "Degree Program: " << degreeString << endl;
	return;
}