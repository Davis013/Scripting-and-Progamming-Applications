#pragma once
#ifndef Student_h
#define Student_h
#include <iostream>
#include <string>
#include "degree.h"
using namespace std;

//Student class header file

class Student {
public:
	Student();
	void SetID(string ID);
	void SetFirstName(string firstName);
	void SetLastName(string lastName);
	void SetEmailAddress(string emailAddress);
	void SetAge(int yearsOld);
	void SetDaysToComplete(int completeTime1, int completeTime2, int completeTime3);
	void SetDegreeProgram(degree degreeProgram);
	string GetID();
	string GetFirstName();
	string GetLastName();
	string GetEmailAddress();
	int GetAge();
	int GetDaysToComplete1();
	int GetDaysToComplete2();
	int GetDaysToComplete3();
	degree GetDegreeProgram();
	void PrintID();
	void PrintFirstName();
	void PrintLastName();
	void PrintEmailAddress();
	void PrintAge();
	void PrintDaysToComplete();
	void PrintDegreeProgram();
	void PrintAllStudentInfo();

	string studentID;
	string firstName;
	string lastName;
	string emailAddress;
	int age;
	int daysToComplete[3];
	degree degreeProgram;
};
#endif 